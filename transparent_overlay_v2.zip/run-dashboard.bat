@echo off
title Screenshot Dashboard Server
echo Starting Screenshot Dashboard Server...
cd /d "%~dp0web"
node server.js
pause
