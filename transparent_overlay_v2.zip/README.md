# Transparent Overlay Capture (Windows)

A native Rust utility for Windows 10/11 x64. On each launch it opens a small native setup window where you can set the status-badge text, show/hide it, and choose whether to enable the fullscreen overlay. It then creates the transparent, click-through Win32 overlay and captures through Windows Graphics Capture (WGC).

## Controls

| Hotkey | Action |
| --- | --- |
| `Ctrl+Shift+S` | Capture the primary display to `screenshots/` |
| `Ctrl+Shift+O` | Show/hide the persistent overlay |
| `Esc` | Emergency hide (the process remains running) |

## Build and run

1. Install stable [Rust](https://rustup.rs/) with the `x86_64-pc-windows-msvc` target and Visual Studio Build Tools (Desktop development with C++).
2. Copy `config.example.toml` to `config.toml`; all defaults work without it.
3. Run `cargo run --release` from this directory.

To enable Telegram, copy `.env.example` to `.env`, populate the two environment variables, then set `telegram.enabled = true` and `telegram.mode = "local_and_telegram"` (or `telegram_only`) in `config.toml`.

## Design and Windows APIs

Stage 1 is implemented by a `WS_POPUP` Win32 window with `WS_EX_LAYERED`, `WS_EX_TOOLWINDOW`, and `WS_EX_NOACTIVATE`. It is placed topmost with `SetWindowPos`; `WM_NCHITTEST` returns `HTTRANSPARENT`, allowing the app beneath it to receive pointer input. To avoid interfering with the Windows taskbar, the invisible layer uses the desktop work area rather than covering the taskbar rectangle. The overlay window persists for the process lifetime and is only shown/hidden by the toggle.

Stage 2 sets `SetWindowDisplayAffinity(hwnd, WDA_EXCLUDEFROMCAPTURE)` immediately after window creation, then uses a WGC Direct3D frame pool/session to obtain a primary-monitor frame. Encoding and file I/O run on a worker thread, leaving the Win32 message loop responsive. The `windows-capture` crate is a narrow WGC/Direct3D wrapper built on `windows`; the project uses `windows` directly for all windowing and hotkey APIs.

Capture exclusion applies to supported Windows capture mechanisms and is not a guarantee against privileged or custom low-level capture techniques.

Stage 3 is included as an optional memory-only Telegram `sendPhoto` delivery path. PNG bytes are uploaded directly; local persistence remains mandatory unless `telegram_only` is explicitly selected.

## Troubleshooting

- **WGC startup fails:** Update to a supported Windows 10 release or Windows 11, update graphics drivers, and check that the desktop session is interactive (not Session 0).
- **Overlay appears in a capture:** Verify the log says `Capture exclusion enabled`; Windows may reject the affinity setting on older builds or certain remote-desktop configurations.
- **Hotkey registration fails:** Another application has registered the same shortcut. Change the defaults in `src/hotkeys.rs` and rebuild.
- **Telegram errors:** Check `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`, bot permissions, and outbound network access.

## Scope and privacy

This project has no persistence, keylogging, process injection, credential collection, or hidden remote-access functionality. It is a visible, user-controlled local desktop utility.
