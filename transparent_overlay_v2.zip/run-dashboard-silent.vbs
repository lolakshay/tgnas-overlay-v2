Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
scriptPath = fso.GetParentFolderName(WScript.ScriptFullName)
WshShell.Run "cmd.exe /c cd /d " & Chr(34) & scriptPath & "\web" & Chr(34) & " && node server.js", 0, false
