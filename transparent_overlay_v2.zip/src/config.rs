use serde::{Deserialize, Serialize};
use std::{fs, path::PathBuf};

#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(default)]
pub struct Config {
    pub overlay: OverlayConfig,
    pub capture: CaptureConfig,
    pub telegram: TelegramConfig,
    pub upload: UploadConfig,
}
#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(default)]
pub struct OverlayConfig {
    pub enabled: bool,
    pub topmost: bool,
    pub click_through: bool,
    pub status_visible: bool,
    pub status_text: String,
}
#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(default)]
pub struct CaptureConfig {
    pub directory: PathBuf,
    pub format: String,
}
#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(default)]
pub struct TelegramConfig {
    pub enabled: bool,
    pub mode: DeliveryMode,
}
#[derive(Clone, Debug, Deserialize, Serialize, PartialEq, Eq)]
#[serde(rename_all = "snake_case")]
pub enum DeliveryMode {
    LocalOnly,
    LocalAndTelegram,
    TelegramOnly,
}
#[derive(Clone, Debug, Deserialize, Serialize)]
#[serde(default)]
pub struct UploadConfig {
    pub enabled: bool,
    pub url: String,
    pub token: String,
}
impl Default for Config {
    fn default() -> Self {
        Self {
            overlay: OverlayConfig::default(),
            capture: CaptureConfig::default(),
            telegram: TelegramConfig::default(),
            upload: UploadConfig::default(),
        }
    }
}
impl Default for OverlayConfig {
    fn default() -> Self {
        Self {
            enabled: true,
            topmost: true,
            click_through: true,
            status_visible: true,
            status_text: "TGNAS eyes on".into(),
        }
    }
}
impl Default for CaptureConfig {
    fn default() -> Self {
        Self {
            directory: PathBuf::from("screenshots"),
            format: "png".into(),
        }
    }
}
impl Default for TelegramConfig {
    fn default() -> Self {
        Self {
            enabled: false,
            mode: DeliveryMode::LocalOnly,
        }
    }
}
impl Default for UploadConfig {
    fn default() -> Self {
        Self {
            enabled: false,
            url: "https://your-vercel-app.vercel.app/api/upload".into(),
            token: "your-device-upload-token".into(),
        }
    }
}
impl Config {
    pub fn load() -> anyhow::Result<Self> {
        let path = PathBuf::from("config.toml");
        if !path.exists() {
            return Ok(Self::default());
        }
        let value = toml::from_str(&fs::read_to_string(path)?)?;
        Ok(value)
    }
    pub fn save(&self) -> anyhow::Result<()> {
        fs::write("config.toml", toml::to_string_pretty(self)?)?;
        Ok(())
    }
}
