use crate::config::Config;
use anyhow::{anyhow, Result};
use std::ffi::c_void;
use windows::{
    core::{w, HSTRING, PCWSTR},
    Win32::{
        Foundation::{HINSTANCE, HWND, LPARAM, LRESULT, WPARAM},
        System::LibraryLoader::GetModuleHandleW,
        UI::WindowsAndMessaging::*,
    },
};

const CLASS: PCWSTR = w!("TransparentOverlay.Settings");
const ID_STATUS_ENABLED: i32 = 101;
const ID_STATUS_TEXT: i32 = 102;
const ID_START_ENABLED: i32 = 103;
const ID_SAVE: i32 = 104;
const ID_CANCEL: i32 = 105;
const CHECKED: usize = 1;

struct State {
    config: *mut Config,
}

/// Shows the lightweight native settings dialog before the overlay is started.
pub unsafe fn show(config: &mut Config) -> Result<()> {
    let instance: HINSTANCE = GetModuleHandleW(None)?.into();
    let wc = WNDCLASSW {
        hInstance: instance,
        lpszClassName: CLASS,
        lpfnWndProc: Some(proc),
        hCursor: LoadCursorW(None, IDC_ARROW)?,
        ..Default::default()
    };
    let atom = RegisterClassW(&wc);
    if atom == 0 && windows::core::Error::from_thread().code().0 != 1410 {
        return Err(anyhow!("RegisterClassW failed"));
    }
    let title = HSTRING::from("TGNAS Overlay Setup");
    let hwnd = CreateWindowExW(
        WS_EX_DLGMODALFRAME,
        CLASS,
        PCWSTR(title.as_ptr()),
        WS_CAPTION | WS_SYSMENU | WS_VISIBLE,
        CW_USEDEFAULT,
        CW_USEDEFAULT,
        410,
        230,
        None,
        None,
        Some(instance),
        None,
    )?;
    let state = Box::new(State { config });
    SetWindowLongPtrW(hwnd, GWLP_USERDATA, Box::into_raw(state) as isize);
    create_controls(hwnd, config)?;
    let mut msg = MSG::default();
    while IsWindow(Some(hwnd)).as_bool() && GetMessageW(&mut msg, None, 0, 0).into() {
        let _ = TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }
    Ok(())
}

unsafe fn create_controls(hwnd: HWND, config: &Config) -> Result<()> {
    let instance: HINSTANCE = GetModuleHandleW(None)?.into();
    CreateWindowExW(
        Default::default(),
        w!("STATIC"),
        w!("Startup configuration"),
        WS_CHILD | WS_VISIBLE,
        18,
        16,
        300,
        24,
        Some(hwnd),
        None,
        Some(instance),
        None,
    )?;
    CreateWindowExW(
        Default::default(),
        w!("BUTTON"),
        w!("Show status badge"),
        WS_CHILD | WS_VISIBLE | WINDOW_STYLE(BS_AUTOCHECKBOX as u32),
        18,
        52,
        160,
        24,
        Some(hwnd),
        Some(menu(ID_STATUS_ENABLED)),
        Some(instance),
        None,
    )?;
    let enabled = if config.overlay.status_visible {
        CHECKED
    } else {
        0
    };
    let _ = SendMessageW(
        control(hwnd, ID_STATUS_ENABLED).ok_or_else(|| anyhow!("status control missing"))?,
        BM_SETCHECK,
        Some(WPARAM(enabled)),
        Some(LPARAM(0)),
    );
    CreateWindowExW(
        Default::default(),
        w!("STATIC"),
        w!("Badge text:"),
        WS_CHILD | WS_VISIBLE,
        18,
        86,
        90,
        22,
        Some(hwnd),
        None,
        Some(instance),
        None,
    )?;
    let text = HSTRING::from(&config.overlay.status_text);
    CreateWindowExW(
        WS_EX_CLIENTEDGE,
        w!("EDIT"),
        PCWSTR(text.as_ptr()),
        WS_CHILD | WS_VISIBLE | WS_TABSTOP | WINDOW_STYLE(ES_AUTOHSCROLL as u32),
        105,
        83,
        270,
        26,
        Some(hwnd),
        Some(menu(ID_STATUS_TEXT)),
        Some(instance),
        None,
    )?;
    CreateWindowExW(
        Default::default(),
        w!("BUTTON"),
        w!("Enable transparent fullscreen overlay"),
        WS_CHILD | WS_VISIBLE | WINDOW_STYLE(BS_AUTOCHECKBOX as u32),
        18,
        122,
        290,
        24,
        Some(hwnd),
        Some(menu(ID_START_ENABLED)),
        Some(instance),
        None,
    )?;
    let start_enabled = if config.overlay.enabled { CHECKED } else { 0 };
    let _ = SendMessageW(
        control(hwnd, ID_START_ENABLED).ok_or_else(|| anyhow!("overlay control missing"))?,
        BM_SETCHECK,
        Some(WPARAM(start_enabled)),
        Some(LPARAM(0)),
    );
    CreateWindowExW(
        Default::default(),
        w!("BUTTON"),
        w!("Save and start"),
        WS_CHILD | WS_VISIBLE | WS_TABSTOP | WINDOW_STYLE(BS_DEFPUSHBUTTON as u32),
        190,
        160,
        105,
        30,
        Some(hwnd),
        Some(menu(ID_SAVE)),
        Some(instance),
        None,
    )?;
    CreateWindowExW(
        Default::default(),
        w!("BUTTON"),
        w!("Cancel"),
        WS_CHILD | WS_VISIBLE | WS_TABSTOP,
        300,
        160,
        75,
        30,
        Some(hwnd),
        Some(menu(ID_CANCEL)),
        Some(instance),
        None,
    )?;
    Ok(())
}

unsafe extern "system" fn proc(hwnd: HWND, msg: u32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    match msg {
        WM_COMMAND if (wp.0 & 0xffff) as i32 == ID_SAVE => {
            let state = GetWindowLongPtrW(hwnd, GWLP_USERDATA) as *mut State;
            if !state.is_null() {
                let config = &mut *(*state).config;
                config.overlay.status_visible = SendMessageW(
                    control(hwnd, ID_STATUS_ENABLED).unwrap_or_default(),
                    BM_GETCHECK,
                    Some(WPARAM(0)),
                    Some(LPARAM(0)),
                )
                .0 as u32
                    == CHECKED as u32;
                config.overlay.enabled = SendMessageW(
                    control(hwnd, ID_START_ENABLED).unwrap_or_default(),
                    BM_GETCHECK,
                    Some(WPARAM(0)),
                    Some(LPARAM(0)),
                )
                .0 as u32
                    == CHECKED as u32;
                let mut buffer = [0u16; 256];
                let length = GetWindowTextW(
                    control(hwnd, ID_STATUS_TEXT).unwrap_or_default(),
                    &mut buffer,
                );
                config.overlay.status_text = String::from_utf16_lossy(&buffer[..length as usize])
                    .trim()
                    .to_owned();
                if config.overlay.status_text.is_empty() {
                    config.overlay.status_text = "TGNAS eyes on".to_owned();
                }
                if let Err(error) = config.save() {
                    tracing::error!(%error, "Could not save configuration");
                }
            }
            let _ = DestroyWindow(hwnd);
            LRESULT(0)
        }
        WM_COMMAND if (wp.0 & 0xffff) as i32 == ID_CANCEL => {
            let _ = DestroyWindow(hwnd);
            LRESULT(0)
        }
        WM_DESTROY => {
            let pointer = SetWindowLongPtrW(hwnd, GWLP_USERDATA, 0) as *mut State;
            if !pointer.is_null() {
                drop(Box::from_raw(pointer));
            }
            LRESULT(0)
        }
        _ => DefWindowProcW(hwnd, msg, wp, lp),
    }
}

unsafe fn control(parent: HWND, id: i32) -> Option<HWND> {
    GetDlgItem(Some(parent), id).ok()
}
const fn menu(id: i32) -> HMENU {
    HMENU(id as usize as *mut c_void)
}
