use crate::{
    config::{CaptureConfig, DeliveryMode, TelegramConfig},
    telegram,
};
use anyhow::{Context, Result};
use image::{ImageBuffer, Rgba};
use std::{path::PathBuf, sync::mpsc};
use windows_capture::{
    capture::{Context as CaptureContext, GraphicsCaptureApiHandler},
    frame::Frame,
    graphics_capture_api::InternalCaptureControl,
    monitor::Monitor,
    settings::{
        ColorFormat, CursorCaptureSettings, DirtyRegionSettings, DrawBorderSettings,
        MinimumUpdateIntervalSettings, SecondaryWindowSettings, Settings,
    },
};

/// WGC callback. The helper crate owns a Direct3D11 frame pool and capture session,
/// exposing the acquired Windows.Graphics.Capture frame as RGBA bytes.
struct OneFrame {
    sender: mpsc::SyncSender<Result<(u32, u32, Vec<u8>)>>,
}
impl GraphicsCaptureApiHandler for OneFrame {
    type Flags = mpsc::SyncSender<Result<(u32, u32, Vec<u8>)>>;
    type Error = anyhow::Error;
    fn new(ctx: CaptureContext<Self::Flags>) -> Result<Self, Self::Error> {
        Ok(Self { sender: ctx.flags })
    }
    fn on_frame_arrived(
        &mut self,
        frame: &mut Frame,
        control: InternalCaptureControl,
    ) -> Result<(), Self::Error> {
        let result = frame
            .buffer()
            .map_err(|e| anyhow::anyhow!(e))
            .map(|buffer| {
                let width = buffer.width();
                let height = buffer.height();
                let mut compact = Vec::new();
                let bytes = buffer.as_nopadding_buffer(&mut compact).to_vec();
                (width, height, bytes)
            });
        let _ = self.sender.send(result);
        control.stop();
        Ok(())
    }
    fn on_closed(&mut self) -> Result<(), Self::Error> {
        Ok(())
    }
}

pub fn spawn_capture(
    config: CaptureConfig,
    telegram_config: TelegramConfig,
    upload_config: crate::config::UploadConfig,
) {
    std::thread::spawn(move || {
        if let Err(error) = capture_and_deliver(config, telegram_config, upload_config) {
            tracing::error!(%error, "Screenshot failed");
        }
    });
}

fn capture_and_deliver(
    config: CaptureConfig,
    telegram_config: TelegramConfig,
    upload_config: crate::config::UploadConfig,
) -> Result<()> {
    tracing::info!("Screenshot requested");
    let monitor = Monitor::primary().context("finding primary display")?;
    let (tx, rx) = mpsc::sync_channel(1);
    let settings = Settings::new(
        monitor,
        CursorCaptureSettings::Default,
        DrawBorderSettings::WithoutBorder,
        SecondaryWindowSettings::Default,
        MinimumUpdateIntervalSettings::Default,
        DirtyRegionSettings::Default,
        ColorFormat::Rgba8,
        tx,
    );
    // start_free_threaded creates the WGC session/frame pool on its own worker thread.
    let control =
        OneFrame::start_free_threaded(settings).context("starting Windows.Graphics.Capture")?;
    let (width, height, rgba) = rx.recv().context("waiting for first WGC frame")??;
    control.wait().context("stopping capture session")?;
    tracing::info!("[INFO] Screenshot captured");
    let image = ImageBuffer::<Rgba<u8>, Vec<u8>>::from_raw(width, height, rgba)
        .context("invalid RGBA frame size")?;
    let png = encode_png(&image)?;
    let save_locally = telegram_config.mode != DeliveryMode::TelegramOnly;
    if save_locally {
        let path = unique_path(&config.directory)?;
        std::fs::write(&path, &png).with_context(|| format!("writing {}", path.display()))?;
        tracing::info!("[INFO] Saved locally: {}", path.display());
    }
    if telegram_config.enabled && telegram_config.mode != DeliveryMode::LocalOnly {
        telegram::send_photo(png.clone())?;
    }
    if upload_config.enabled {
        let mut delay = std::time::Duration::from_secs(2);
        let mut success = false;
        for attempt in 1..=3 {
            match upload_to_server(&upload_config, &png) {
                Ok(_) => {
                    tracing::info!("[INFO] Upload successful");
                    success = true;
                    break;
                }
                Err(error) => {
                    tracing::warn!(%error, attempt, "Upload attempt failed");
                    if attempt < 3 {
                        std::thread::sleep(delay);
                        delay *= 2;
                    }
                }
            }
        }
        if !success {
            tracing::warn!("[WARN] Screenshot upload failed");
            tracing::info!("[INFO] Screenshot preserved locally");
        }
    }
    Ok(())
}

fn upload_to_server(upload_config: &crate::config::UploadConfig, png: &[u8]) -> Result<()> {
    let client = reqwest::blocking::Client::builder()
        .timeout(std::time::Duration::from_secs(30))
        .build()?;
    let form = reqwest::blocking::multipart::Form::new()
        .part(
            "screenshot",
            reqwest::blocking::multipart::Part::bytes(png.to_vec())
                .file_name("screenshot.png")
                .mime_str("image/png")?,
        );
    let response = client
        .post(&upload_config.url)
        .header("Authorization", format!("Bearer {}", upload_config.token))
        .multipart(form)
        .send()
        .context("calling upload API")?;
    if !response.status().is_success() {
        let status = response.status();
        let body = response.text().unwrap_or_default();
        anyhow::bail!("Upload server returned status {}: {}", status, body);
    }
    Ok(())
}

fn encode_png(image: &ImageBuffer<Rgba<u8>, Vec<u8>>) -> Result<Vec<u8>> {
    let mut output = std::io::Cursor::new(Vec::new());
    image
        .write_to(&mut output, image::ImageFormat::Png)
        .context("encoding PNG")?;
    Ok(output.into_inner())
}
fn unique_path(directory: &PathBuf) -> Result<PathBuf> {
    std::fs::create_dir_all(directory)
        .with_context(|| format!("creating {}", directory.display()))?;
    for suffix in 0..10_000u32 {
        let base = chrono::Local::now()
            .format("screenshot_%Y%m%d_%H%M%S")
            .to_string();
        let name = if suffix == 0 {
            format!("{base}.png")
        } else {
            format!("{base}_{suffix}.png")
        };
        let path = directory.join(name);
        if !path.exists() {
            return Ok(path);
        }
    }
    anyhow::bail!("could not allocate a unique screenshot filename")
}
