use anyhow::{anyhow, Result};
use std::mem::size_of;
use windows::{
    core::{w, HSTRING, PCWSTR},
    Win32::{
        Foundation::{COLORREF, HINSTANCE, HWND, LPARAM, LRESULT, RECT, WPARAM},
        Graphics::Gdi::{
            BeginPaint, CreateSolidBrush, DeleteObject, DrawTextW, EndPaint, FillRect, SetBkMode,
            SetTextColor, DT_CENTER, DT_SINGLELINE, DT_VCENTER, PAINTSTRUCT, TRANSPARENT,
        },
        System::LibraryLoader::GetModuleHandleW,
        UI::WindowsAndMessaging::*,
    },
};

const CLASS: PCWSTR = w!("TransparentOverlay.StatusBadge");
pub struct StatusBadge {
    hwnd: HWND,
}
impl StatusBadge {
    pub unsafe fn create(text: &str, show: bool) -> Result<Option<Self>> {
        if !show {
            return Ok(None);
        }
        let instance: HINSTANCE = GetModuleHandleW(None)?.into();
        let wc = WNDCLASSEXW {
            cbSize: size_of::<WNDCLASSEXW>() as u32,
            hInstance: instance,
            lpszClassName: CLASS,
            lpfnWndProc: Some(proc),
            ..Default::default()
        };
        let atom = RegisterClassExW(&wc);
        if atom == 0 && windows::core::Error::from_thread().code().0 != 1410 {
            return Err(anyhow!("RegisterClassExW failed"));
        }
        let value = Box::new(HSTRING::from(text));
        let hwnd = CreateWindowExW(
            WS_EX_LAYERED | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE,
            CLASS,
            w!(""),
            WS_POPUP,
            16,
            16,
            190,
            30,
            None,
            None,
            Some(instance),
            Some(Box::into_raw(value).cast()),
        )?;
        SetLayeredWindowAttributes(hwnd, COLORREF(0), 190, LWA_ALPHA)
            .ok()
            .ok_or_else(|| anyhow!("SetLayeredWindowAttributes failed"))?;
        SetWindowDisplayAffinity(hwnd, WDA_EXCLUDEFROMCAPTURE).ok();
        SetWindowPos(
            hwnd,
            Some(HWND_TOPMOST),
            16,
            16,
            190,
            30,
            SWP_NOACTIVATE | SWP_SHOWWINDOW,
        )
        .ok()
        .ok_or_else(|| anyhow!("SetWindowPos failed"))?;
        Ok(Some(Self { hwnd }))
    }
}
impl Drop for StatusBadge {
    fn drop(&mut self) {
        unsafe {
            let _ = DestroyWindow(self.hwnd);
        }
    }
}
unsafe extern "system" fn proc(hwnd: HWND, msg: u32, wp: WPARAM, lp: LPARAM) -> LRESULT {
    match msg {
        WM_NCCREATE => {
            let create = &*(lp.0 as *const CREATESTRUCTW);
            SetWindowLongPtrW(hwnd, GWLP_USERDATA, create.lpCreateParams as isize);
            LRESULT(1)
        }
        WM_NCHITTEST => LRESULT(HTTRANSPARENT as isize),
        WM_PAINT => {
            let mut ps = PAINTSTRUCT::default();
            let hdc = BeginPaint(hwnd, &mut ps);
            let mut rect = RECT {
                left: 0,
                top: 0,
                right: 190,
                bottom: 30,
            };
            let brush = CreateSolidBrush(COLORREF(0x202020));
            let _ = FillRect(hdc, &rect, brush);
            let _ = DeleteObject(brush.into());
            let _ = SetBkMode(hdc, TRANSPARENT);
            let _ = SetTextColor(hdc, COLORREF(0xF0F0F0));
            let ptr = GetWindowLongPtrW(hwnd, GWLP_USERDATA) as *const HSTRING;
            if !ptr.is_null() {
                let text = &*ptr;
                let mut characters: Vec<u16> = text.to_string().encode_utf16().collect();
                let _ = DrawTextW(
                    hdc,
                    &mut characters,
                    &raw mut rect,
                    DT_CENTER | DT_VCENTER | DT_SINGLELINE,
                );
            }
            let _ = EndPaint(hwnd, &ps);
            LRESULT(0)
        }
        WM_NCDESTROY => {
            let ptr = SetWindowLongPtrW(hwnd, GWLP_USERDATA, 0) as *mut HSTRING;
            if !ptr.is_null() {
                drop(Box::from_raw(ptr));
            }
            DefWindowProcW(hwnd, msg, wp, lp)
        }
        _ => DefWindowProcW(hwnd, msg, wp, lp),
    }
}
