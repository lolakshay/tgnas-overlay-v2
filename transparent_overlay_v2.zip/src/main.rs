#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

mod capture;
mod config;
mod config_ui;
mod hotkeys;
mod overlay;
mod status_badge;
mod telegram;

use anyhow::Result;
use windows::Win32::UI::WindowsAndMessaging::{
    DispatchMessageW, GetMessageW, TranslateMessage, MSG, WM_HOTKEY,
};

fn main() -> Result<()> {
    dotenvy::dotenv().ok();
    tracing_subscriber::fmt()
        .with_env_filter(tracing_subscriber::EnvFilter::from_default_env())
        .init();
    let mut config = config::Config::load()?;
    unsafe {
        config_ui::show(&mut config)?;
    }
    if config.capture.format.to_lowercase() != "png" {
        anyhow::bail!("only PNG is currently supported");
    }
    tracing::info!("Starting transparent overlay");
    unsafe {
        let mut overlay = overlay::Overlay::create(config.overlay.enabled, config.overlay.topmost)?;
        let _status_badge = status_badge::StatusBadge::create(
            &config.overlay.status_text,
            config.overlay.status_visible,
        )?;
        let _hotkeys = hotkeys::RegisteredHotkeys::register(&hotkeys::HotkeyConfig::default())?;
        tracing::info!("Overlay created; global hotkeys registered");
        let mut msg = MSG::default();
        while GetMessageW(&mut msg, None, 0, 0).into() {
            if msg.message == WM_HOTKEY {
                match msg.wParam.0 as i32 {
                    hotkeys::SCREENSHOT_ID => {
                        capture::spawn_capture(
                            config.capture.clone(),
                            config.telegram.clone(),
                            config.upload.clone(),
                        )
                    }
                    hotkeys::TOGGLE_OVERLAY_ID => overlay.toggle()?,
                    hotkeys::EMERGENCY_OFF_ID => overlay.set_visible(false)?,
                    _ => {}
                }
            }
            let _ = TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }
    }
    Ok(())
}
