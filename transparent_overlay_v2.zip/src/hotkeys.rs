use windows::Win32::UI::Input::KeyboardAndMouse::{
    RegisterHotKey, UnregisterHotKey, HOT_KEY_MODIFIERS, MOD_CONTROL, MOD_SHIFT, VIRTUAL_KEY,
};

pub const SCREENSHOT_ID: i32 = 1;
pub const TOGGLE_OVERLAY_ID: i32 = 2;
pub const EMERGENCY_OFF_ID: i32 = 3;

pub struct HotkeyConfig {
    pub screenshot: (HOT_KEY_MODIFIERS, VIRTUAL_KEY),
    pub toggle_overlay: (HOT_KEY_MODIFIERS, VIRTUAL_KEY),
    pub emergency_disable: (HOT_KEY_MODIFIERS, VIRTUAL_KEY),
}
impl Default for HotkeyConfig {
    fn default() -> Self {
        Self {
            screenshot: (MOD_CONTROL | MOD_SHIFT, VIRTUAL_KEY(b'S' as u16)),
            toggle_overlay: (MOD_CONTROL | MOD_SHIFT, VIRTUAL_KEY(b'O' as u16)),
            emergency_disable: (HOT_KEY_MODIFIERS(0), VIRTUAL_KEY(0x1B)),
        }
    }
}
pub struct RegisteredHotkeys;
impl RegisteredHotkeys {
    pub unsafe fn register(config: &HotkeyConfig) -> windows::core::Result<Self> {
        RegisterHotKey(
            None,
            SCREENSHOT_ID,
            config.screenshot.0,
            u32::from(config.screenshot.1 .0),
        )?;
        RegisterHotKey(
            None,
            TOGGLE_OVERLAY_ID,
            config.toggle_overlay.0,
            u32::from(config.toggle_overlay.1 .0),
        )?;
        RegisterHotKey(
            None,
            EMERGENCY_OFF_ID,
            config.emergency_disable.0,
            u32::from(config.emergency_disable.1 .0),
        )?;
        Ok(Self)
    }
}
impl Drop for RegisteredHotkeys {
    fn drop(&mut self) {
        unsafe {
            for id in [SCREENSHOT_ID, TOGGLE_OVERLAY_ID, EMERGENCY_OFF_ID] {
                let _ = UnregisterHotKey(None, id);
            }
        }
    }
}
